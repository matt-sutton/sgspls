####################################
### Extra functions for analysis ###
####################################


#' Find selected Modules, Genes and Times
#'
#' This function finds the selected groups, subgroups and individual predictors
#' from a sgsPLS method.
#'
#' @param model object of class inhereting from "sgsPLS".
#' @param module A p-vector indicating group membership for each covariate in
#'   the X-block
#' @param gene A p-vector indicating gene membership for each covariate in
#'   the X-block
#' @param time A p-vector indicating time membership for each covariate in
#'   the X-block
#'
#' @export
#' @return Returns a list with the following selected parameter information:
#'
#' \item{select.table.X}{A table detailing the number of times each gene has been selected at each timepoint and the number of consistently selected genes.}
#' \item{summary.table}{A table sumarising the number of modules, genes, timepoints and covariates selected.}
#' \item{tab.gene.X}{Lists the number of timepoint that each gene in a given module and component occurs.}
#' \item{tab.gene.time.X}{Table of the selected genes against time points that they occur.}
#' \item{consistent.genes.X}{Returns the genes that occur in every time point.}
#' \item{select.gene.X}{Returns the genes that are selected at least once for a given component.}
#' \item{select.gene.X.total}{Returns the genes that are selected at least once across any component.}
#' \item{selected.table.gene.X}{Returns the total number of genes selected at each component.}
#'
#' @examples
#'
#'n = 100; p = 200; size.groups = 25; size.subgroups = 5
#'groupX <- ceiling(1:p / size.groups)
#'subgroupX <- ceiling(1:p / size.subgroups)
#'X = matrix(rnorm(n * p), ncol = p, nrow = n)
#'
#'beta <- rep(0,p)
#'
#' # There are 40 genes split into 8 modules of 5 genes
#' # Each b.module contains 5 genes from all 5 time points
#' # Each b.time subgroup contains the expressions of the 5 genes
#' # at that time point
#'
#' b.time <- -2:2; b.0 <- rep(0,length(b.time))
#' b.module <- c(b.time, b.0, b.time, b.0, b.0)
#' beta[1:size.groups] <- b.module
#' # Beta contains 1 active module with 2 active time points
#' # and 5 active genes
#'
#' # index for modules, genes and times
#' mod.index <- groupX
#' gene.index <- as.vector(sapply(0:7, function(X) rep(1:5,5) + X*5))
#' time.index <- rep(rep(1:5,each = 5), 8)
#'
#' y = X %*% beta + 0.1*rnorm(n)
#'
#' model.sgsPLS <- sgsPLS(X, y, ncomp = 3, mode = "regression", keepX = 1,
#'                        groupX = groupX, subgroupX = subgroupX,indiv.sparsity.x = 0.8,
#'                        subgroup.sparsity.x = 0.15, penalty = "sgsgPLS")
#' model.sgsPLSR <- predict(model.sgsPLS, X)
#'
#' # See the estimated regression coefficient
#' cbind(model.sgsPLSR$B.hat[,,3], beta, mod.index, gene.index, time.index)[1:30,]
#'
#' selectedVar <- select.sgspls(model.sgsPLS, module = mod.index, gene = gene.index, time = time.index)
#'
#' # show number of selected genes for component 1
#' selectedVar$select.table.X$comp1
#'
#' # show number of modules, genes, times and total variables selected
#' selectedVar$summary.table
#'
#' # Show when genes were selected from given module
#' selectedVar$tab.gene.time.X$comp1$M1
#'
#' # Shows the number of times each gene is selected
#' selectedVar$tab.gene.X$comp1$M1
#'
#' # Shows which genes were consistently selected
#' selectedVar$consistent.genes.X$comp1
#'
#' # Shows which genes were selected over all modules
#' selectedVar$select.gene.X$comp1
#'
#' # Shows which genes were selected over all modules over all components
#' selectedVar$select.gene.X.total
#'
#' # shows number of genes selected at any timepoint within each module
#' selectedVar$selected.table.gene.X
#'

select.sgspls <- function (model, module, gene, time) {
  ### Selected variable metrics
  ## Genes, modules, and number indivduals selected. + table for times
  module <- as.factor(paste0("M",module))
  gene <- paste0("G", gene)
  result <- vector("list", length = model$ncomp)
  res.select <- vector("list", length = model$ncomp)
  tab.gene <- vector("list", length = model$ncomp)
  tab.gene.time <- vector("list", length = model$ncomp)
  consistent.genes <- vector("list", length = model$ncomp)
  names(result) <- names(res.select) <- names(tab.gene) <- names(tab.gene.time) <- names(consistent.genes) <- paste0("comp",1:model$ncomp)

  result.summary <- matrix(0, nrow = model$ncomp, ncol = 4)
  colnames(result.summary) <- c("# Modules", "# Genes", "# Times", " Total ")
  rownames(result.summary) <- paste0("comp ",1:model$ncomp)

  n.modules <- length(unique(module))
  n.times <- length(unique(time))
  size.group <- diag(table(module[time==1], module[time==1]))

  tab.gene.select <- matrix(0, nrow = n.modules, ncol = 1 + model$ncomp)
  tab.gene.select[,1] <- size.group
  colnames(tab.gene.select) <- c("size.group", paste0("comp ",1:model$ncomp))
  rownames(tab.gene.select) <- unique(module)

  for (h in 1:model$ncomp) {
    set.ind.zero <- which(abs(model$loadings$X[, h]) > 0)
    # summary stats
    ns.mod <- length(unique(module[set.ind.zero]))
    ns.gene <- length(unique(gene[set.ind.zero]))
    ns.time <- length(unique(time[set.ind.zero]))
    ns <- length(set.ind.zero)
    result.summary[h,] <- c(ns.mod, ns.gene, ns.time, ns)

    names(set.ind.zero) <- model$names$X[set.ind.zero]
    res.select[[h]] <- set.ind.zero
    res.gene.time <- res.gene <- vector("list", length = n.modules)
    names(res.gene.time )<-names(res.gene) <- unique(module)
    consistent <- res <- NULL
    for (mod in 1:n.modules) {

      inds <- intersect(set.ind.zero,which(as.numeric(module)==mod))
      res.gene.time[[mod]] <- smods <- table(as.character(gene[inds]), time[inds])
      res.gene[[mod]] <- sort(rowSums(smods),decreasing = T)
      consistent <- c(consistent,length(which(rowSums(smods)==n.times)))
      temp <- rep(0,n.times)
      temp[as.numeric(names(colSums(smods)))] <- colSums(smods)
      res <- rbind(res, temp)

    }
    tab.gene.time[[h]] <- res.gene.time
    tab.gene[[h]] <- res.gene
    colnames(res) <- paste0("T",1:ncol(res))
    result[[h]] <- cbind(size.group, consistent, res)
    tab.gene.select[,h+1] <- unlist(lapply(res.gene, function(x) length(x)))
    consistent.genes[[h]] <- unlist(lapply(res.gene, function(x) names(which(x==6))))
    cons.names <- NULL
#     for(i in 1:n.modules){
#       cons.names <- c(cons.names, rep(unique(as.character(module))[i], consistent[i]))
#     }
#     names(consistent.genes[[h]]) <- cons.names
  }
  select.x <- lapply(res.select, function(x) unique(as.character(gene[x])))
  ind.total.x <- sort(unique(as.character(unlist(select.x))))
  return(list(select.table.X = result, summary.table = result.summary, tab.gene.X = tab.gene,  tab.gene.time.X = tab.gene.time,
              consistent.genes.X = consistent.genes,select.gene.X = select.x,
              select.gene.X.total = ind.total.x, selected.table.gene.X = tab.gene.select))
}

# Duplicate penalty parameter to match the number of components
add.penalty.param <- function(arg, ncomp){
  if(ncomp != length(arg)){
    arg = rep(arg, length.out = ncomp)
  }
  return(arg)
}

#' Compute the euclidian norm
#'
#' Computes the L2-norm of a vector \code{x}. A float 1e-16 is returned if the
#' exact value is 0 so that division in the PLS algorithm is well defined.
#'
#' @param x A vector of numeric variables
#'
#' @return Output will be a length-one numeric.
#'

e.norm <- function(x, exact=FALSE){
  res = sqrt(drop(crossprod(x)))
  if(!exact) res = res+(res==0)*1
  return(res)
}

# scale and center a matrix
pls.scale <- function(X, scale.x){
  meanx <- apply(X, MARGIN = 2, mean)
  normx <- rep(1,ncol(X))
  if(scale.x) {
    normx <- apply(X, 2, sd)
    if (any(normx < .Machine$double.eps)) {
      stop("Some of the columns of the predictor matrix have zero variance.")
    }
  }
  X = scale(X,meanx,normx)
  attr(X, "scaled:scaled") <- normx
  return(X)
}


#' Return the nonzero columns and rows
#'
#' Quick function for finding the nonzero columns of a matrix.
#'
#' @param Z A matrix of variables, where some columns or rows are entierly zero.
#' @param thresh A threshold value to round values off at.
#' @param zero.col A vector of columns to take for the removal of the matrix.
#'
#' @examples
#' a <- matrix(c(rep(0,3),1,0,1,rep(0,3)),3,3)
#' a
#' nonZero(a) #removes all rows and columns with nonzero elements
#' nonZero(a,zero.col = 2) # removes only nonzero rows and columns from row 2.

nonZero <- function(Z, thresh = 1e-06,zero.col = NULL){
  if(is.null(zero.col)) {
    Z.nz = if(is.null(dim(Z))) Z[which(abs(Z)>thresh)] else Z[rowSums(abs(Z))>thresh,colSums(abs(Z))>thresh]
  }
  else {
    Z.nz = if(length(zero.col)==1) Z[which(abs(Z[,zero.col])>thresh),] else Z[rowSums(abs(Z[,zero.col]))>thresh,colSums(abs(Z[,zero.col]))>thresh]
  }
  return(Z.nz)
}

#' Plot the cross validation curves of a sgsPLS.cv object
#'
#' Produces a plot of the cross validation curves for a "sgsPLS.cv" object.
#'
#' @param obj fitted sgsPLS.cv object
#'
#' @seealso sgsPLS.tune, perf
#'
#'
plot.cv.sgsPLS <- function(obj, verbose = T){
  if(verbose){
    library(knitr)
    cat("\n ========================================== \n")
    cat("\n",obj$folds,"fold Cross Validation for sgsPLS \n\n")
    nalpha <- length(obj$tuning.parameters[,1])

    cat( " Tuning Parameters:")
    table <- data.frame(Legend = paste("alpha",1:nalpha,sep = "_"),obj$tuning.parameters)
    print(kable(table, format = "pandoc"))
    cat("\n ========================================== \n")
  }

  legendVal <- parse(text = paste("alpha[",1:nalpha,"]",sep=""))
  group.seq <- obj$group.seq
  cv.scores <- obj$results.tuning[,4]
  cv.scores <- matrix(cv.scores, nrow = length(group.seq), ncol = nalpha)
  minalpha <- which(cv.scores == min(cv.scores), arr.ind = T)[2]
  alphawidth <- rep(1,nalpha)
  alphawidth[minalpha] <- 3

  # get nice Y-range
  placement = max(cv.scores[1,]) > max(cv.scores[nrow(cv.scores),])

  if(placement) {
    maxy<- max(cv.scores[nrow(cv.scores),]) + max(0.8*(max(cv.scores[1,])-max(cv.scores[nrow(cv.scores),])), 0.2)
    miny <- min(cv.scores)
  } else{
    miny <- min(cv.scores[nrow(cv.scores),]) - max(min(cv.scores[nrow(cv.scores),]) - min(cv.scores[1,]), 0.2)
    maxy <- max(c(cv.scores[nrow(cv.scores),],cv.scores[1,]))
  }

  placement <- if(placement) "topright" else "bottomright"
  matplot(group.seq,cv.scores,type="l",ylab="MSEP",ylim = c(miny,maxy),
          pch=1,col=rainbow(nalpha),lty=1:nalpha,lwd=1.5*alphawidth,xlab="Number of groups")

  # How many colums to use <10 = 1, <20 = 2, <30 = 3, otherwise 4.
  ncols <- which(table(cut(nalpha, breaks = c(0,10,20,30,100)))>0)

  legend(placement,legendVal,ncol=ncols,col = rainbow(nalpha),lty=1:nalpha,lwd=alphawidth)

}
